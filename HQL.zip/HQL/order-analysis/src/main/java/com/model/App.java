package com.model;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class App 
{
    public static void main( String[] args )
    {
        SessionFactory factory = new Configuration()
                .configure()
                .buildSessionFactory();

        Session session = factory.openSession();

        Scanner sc = new Scanner(System.in);
        while(true){

            System.out.println("Order-Analysis");
            System.out.println("1 Insert Order");
            System.out.println("2 Show All Orders");
            System.out.println("3 Orders by User");
            System.out.println("4 Total Sales");
            System.out.println("5 Exit");

            int choice = sc.nextInt();
            Transaction tx=session.beginTransaction();

            switch(choice){
                case 1->{
                      sc.nextLine();

                    System.out.println("Enter Item:");
                    String item = sc.nextLine();

                    System.out.println("Enter Total:");
                    double total = sc.nextDouble();

                    System.out.println("Enter User ID:");
                    int uid = sc.nextInt();

                    Order order = new Order();
                    order.setItem(item);
                    order.setTotal(total);
                    order.setUserId(uid);
                    order.setDate(new Date());

                    session.save(order);

                    System.out.println("Order Inserted");

                    break;
                }
                case 2->{
                    Query q1 = session.createQuery("from Order");

                    List<Order> list = q1.list();
                    System.out.println("Order Id "+"  Item  "+"  Total Bill  "+"  User Id  "+"  Date:   ");
                    for(Order o : list){
                        
                        System.out.println(o.getId()+" | "+
                                             o.getItem()+"  | "+
                                             o.getTotal()+"  |  "+
                                             o.getUserId()+"  |  "+
                                             o.getDate());

                    }

                    break;
                }
                case 3 ->{
 
                    System.out.println("Enter User ID:");
                    int id = sc.nextInt();

                    Query q2 = session.createQuery("from Order where userId=:u");
                    q2.setParameter("u",id);

                    List<Order> orders = q2.list();
                    double totalBill=0;
                    for(Order o : orders){
                        System.out.println("Item: "+o.getItem()+" "
                        +"Bill: "+o.getTotal()+" "
                        +"Date: "+o.getDate());
                        totalBill=totalBill+o.getTotal();
                    }
                       System.out.println("Total Bill : "+totalBill);
                    break;
                }
                case 4->{

                    Query q3 = session.createQuery("select sum(total) from Order");

                    Double sum = (Double) q3.uniqueResult();

                    System.out.println("Total Sales: "+sum);

                    break;
                }
                case 5->{

                    session.close();
                    factory.close();
                    System.exit(0);
                }
            }

            tx.commit();

                }
            }
    }
 

