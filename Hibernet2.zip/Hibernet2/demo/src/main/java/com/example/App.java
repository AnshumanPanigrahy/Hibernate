package com.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class App {

   public static void main(String[] args) {

       SessionFactory factory =
               new Configuration()
               .configure("hibernate.cfg.xml")
               .addAnnotatedClass(Student.class)
               .buildSessionFactory();

       Session session = factory.openSession();

       session.beginTransaction();

       Student student = new Student("Partha", 335);

       session.save(student);

       session.getTransaction().commit();

       session.close();
       factory.close();

       System.out.println("Data inserted successfully");

   }
}
