package com.model;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class App {

    public static void main(String[] args) {

        SessionFactory factory = new Configuration()
                .configure()
                .buildSessionFactory();

        Session session = factory.openSession();

        Scanner sc = new Scanner(System.in);

        while(true){

            System.out.println("\n===== Library Search Engine =====");
            System.out.println("1 Insert Book");
            System.out.println("2 Search Book");
            System.out.println("3 Update Book");
            System.out.println("4 Delete Book");
            System.out.println("5 Show All Books");
            System.out.println("6 Exit");

            int choice = sc.nextInt();
            sc.nextLine();

            Transaction tx = session.beginTransaction();

            switch(choice){

                case 1 -> {
                    System.out.println("Enter Title:");
                    String title=sc.nextLine();

                    System.out.println("Enter Author:");
                    String author=sc.nextLine();

                    System.out.println("Enter Category:");
                    String category=sc.nextLine();

                    Book b=new Book(title,author,category);

                    session.save(b);

                    System.out.println("Book Inserted");
                }


                case 2 -> {
                    System.out.println("Enter title to search:");
                    String t=sc.nextLine();

                    Query q=session.createQuery("from Book where title=:t");
                    q.setParameter("t",t);

                    List<Book> list=q.list();

                    for(Book book:list){
                        System.out.println("The Book id is: "+book.getId()+" "
                                +"The Book Name is: "+book.getTitle()+" "
                                +"The Book Auther Name is: "+book.getAuthor()+" "
                                +"The Book catogory is: "+book.getCategory());
                    }
                }


                case 3 -> {
                    System.out.println("Enter Book ID to update:");
                    int id=sc.nextInt();
                    sc.nextLine();

                    Book book=session.get(Book.class,id);

                    if(book!=null){

                        System.out.println("Enter new title:");
                        book.setTitle(sc.nextLine());

                        session.update(book);

                        System.out.println("Book Updated");
                    }
                }


                case 4 -> {
                    System.out.println("Enter Book ID to delete:");
                    int did=sc.nextInt();

                    Book db=session.get(Book.class,did);

                    if(db!=null){

                        session.delete(db);
                        System.out.println("Book Deleted");

                    }
                }


                case 5 -> {
                    Query all = session.createQuery("from Book");
                    
                    List<Book> books = all.list();
                    
                    for(Book c : books){
                        
                        System.out.println(c.getId()+" "
                                +c.getTitle()+" "
                                +c.getAuthor()+" "
                                +c.getCategory());
                        
                    }
                }


                case 6 -> {
                    session.close();
                    factory.close();
                    System.exit(0);
                }

            }

            tx.commit();

        }

    }
}