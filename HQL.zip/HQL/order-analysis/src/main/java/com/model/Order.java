package com.model;
//id | item | total | UserId |date.
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="orders")
public class Order{
   


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String item;
    private double total;
    private int UserId;
    
     @Temporal(TemporalType.DATE)
      private Date date;

    public Order(){}
    

    public Order(String item,int total,int UserId,Date date){
        this.item=item;
        this.total=total;
        this.UserId=UserId;
        this.date=date;
    }

   public int getId(){
        return id;
   }
   public String getItem(){
    return item;
   }
   public double getTotal(){
    return total;
   }
   public int getUserId(){
    return UserId;  
   }
   public Date getDate(){
        return date;
    }
   public void setId(int id){
      this.id=id;
   }
   public void setItem(String item){
    this.item=item;
   }
   public void setTotal(double total){
      this.total=total;
   }
   public void setUserId(int UserId){
    this.UserId=UserId;
   }
    public void setDate(Date date){
        this.date=date;
    }
}